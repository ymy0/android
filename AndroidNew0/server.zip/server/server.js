var express = require("express");
var app = express();
var hostName = '127.0.0.1';
var port = 8080;
var bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({extended: false}));
 
// bodyParser.json解析json数据格式的
app.use(bodyParser.json());

var getAllState=require('./JS/getAllState');
var changeKey=require('./JS/changeKey');
var changeValue=require('./JS/changeValue');
//var getKeyData=require('./JS/getKeyData');
var source=require('./JS/airConditioning');
var changeModel=require('./JS/changeModel');
var changeSpeed=require('./JS/changeSpeed');
// var month=2018/07;
var datetime =4;
var hour=22;
var record={
    isOk: true,
    data: {
      temperatures: [
        {id:"01",date: "4/21", temperature: ""+source.air1.temperature+""},
        {id:"02",date: "4/21", temperature: ""+source.air2.temperature+""},
        {id:"03",date: "4/21", temperature: ""+source.air3.temperature+""},
        {id:"04",date: "4/21", temperature: ""+source.air4.temperature+""},
      ]
    }
  }
var record1={
    isOk: true,
    data: {
      temperatures: [
        {id:"01",date: "4/21", temperature: ""+source.air1.temperature+""}
      ]
    }
  }
  var record2={
    isOk: true,
    data: {
      temperatures: [
        {id:"02",date: "4/21", temperature: ""+source.air2.temperature+""}
      ]
    }
  }
  var record3={
    isOk: true,
    data: {
      temperatures: [
        {id:"03",date: "4/21", temperature: ""+source.air3.temperature+""}
      ]
    }
  }
  var record4={
    isOk: true,
    data: {
      temperatures: [
        {id:"04",date: "4/21", temperature: ""+source.air4.temperature+""}
      ]
    }
  }
var count=0;
var count1=0;
var count2=0;
var count3=0;
var count4=0;
setInterval(function(){
    if(hour<25) hour=hour+1;
    else {hour=hour-24;
    datetime++;
    
    record1.data.temperatures[count1]={id:"01",date:""+datetime+"+"/"+"+hour+"",temperature:""+source.air1.temperature+""};
    record.data.temperatures[count]=record1.data.temperatures[count1];count++;
    record2.data.temperatures[count2]={id:"02",date:""+datetime+"+"/"+"+hour+"",temperature:""+source.air1.temperature+""};
    record.data.temperatures[count]=record1.data.temperatures[count1];count++;
    record3.data.temperatures[count3]={id:"03",date:""+datetime+"+"/"+"+hour+"",temperature:""+source.air1.temperature+""};
    record.data.temperatures[count]=record1.data.temperatures[count1];count++;
    record4.data.temperatures[count4]={id:"04",date:""+datetime+"+"/"+"+hour+"",temperature:""+source.air1.temperature+""};
    record.data.temperatures[count]=record1.data.temperatures[count1];count++;
    count1++;
    count2++;
    count3++;
    count4++;
}
},3600000);
app.get("/:id",function(req,res){
        var ID = req.params.id;
        switch(ID){
        case '00': getAllState(function(){ res.send(source);});
        break;

        case '01': getAllState(function(){ res.send(source.air1);
        });
        break;

        case '02': getAllState(function(){ res.send(source.air2);});
        break;

        case '03': getAllState(function(){ res.send(source.air3);});
        break;

        case '04': getAllState(function(){ res.send(source.air4);});
        break;
        default: res.send("error--can't find the url you want to get");
        }
});
app.get("/00/getrecord",function(req,res){
    res.send(record);
});
app.get("/01/getrecord",function(req,res){
    res.send(record1);
});
app.get("/02/getrecord",function(req,res){
    res.send(record2);
});
app.get("/03/getrecord",function(req,res){
    res.send(record3);
});
app.get("/04/getrecord",function(req,res){
    res.send(record4);
});
app.post("/changestatus",function(req,res){
        var responseData={
            isOk:true,
            error:""
        }
        var ID=req.body.id;
        var key=req.body.data.key;
        var value=req.body.data.value;
        value=Number(value); 
            switch(ID){
            case '01':switch(key){
                case'speed':if(value>-1&&value<5&&source.air1.key==1)  {
                    responseData.isOk=true;
                    changeSpeed(1,value,function(){
                    res.send(responseData);
                });}
                else {
                    responseData.isOk=false;
                    responseData.error="the value is incorrect，it should be 0-4;Or the Air conditioning is shut down";
                    res.send(responseData);
                }
                break;
                case'temperature':
                if(value>19&&value<31&&source.air1.key==1){
                    
                        responseData.isOk=true;
                    getAllState(function(){ 
                        changeValue(1,value,function(){
                            res.send(responseData);
                            });
                    });
                }
                else {
                        responseData.isOk=false;
                        responseData.error="the value is incorrect，it should be 20-30;Or the Air conditioning is shut down";
                        res.send(responseData);
                    }
                break;
                case'mode':if(value>-1&&value<5&&source.air1.key==1)  {
                    responseData.isOk=true;
                    changeModel(1,value,function(){
                    res.send(responseData);
                });}
                else {
                    responseData.isOk=false;
                    responseData.error="the value is incorrect，it should be 0-4;Or the Air conditioning is shut down";
                    res.send(responseData);
                }
                break;
                case'key':if(value==0||value==1)  {
                    responseData.isOk=true;
                    changeKey(1,value,function(){
                        //console.log("????")
                    res.send(responseData);
                });}
                else {
                    responseData.isOk=false;
                    responseData.error="the value is incorrect，it should be '0'or'1'";
                    res.send(responseData);
                }
                break;
                default: 
                responseData.isOk=false;
                responseData.error="your key is not existent";
                res.send(responseData);
            }
            break;

            case '02':switch(key){
                case'speed':if(value>-1&&value<5&&source.air2.key==1)  {
                    responseData.isOk=true;
                    changeSpeed(2,value,function(){
                    res.send(responseData);
                });}
                else {
                    responseData.isOk=false;
                    responseData.error="the value is incorrect，it should be 0-4";
                    res.send(responseData);
                }
                break;
                case'temperature':
                if(value>19&&value<31&&source.air2.key==1){
                        responseData.isOk=true;
                        getAllState(function(){ 
                    changeValue(2,value,function(){
                    res.send(responseData);
                    });});
                }
                else {
                        responseData.isOk=false;
                        responseData.error="the value is incorrect，it should be 20-30";
                        res.send(responseData);
                    }
                break;
                case'mode':if(value>-1&&value<5&&source.air2.key==1)  {
                    responseData.isOk=true;
                    changeModel(2,value,function(){
                    res.send(responseData);
                });}
                else {
                    responseData.isOk=false;
                    responseData.error="the value is incorrect，it should be 0-4";
                    res.send(responseData);
                }
                break;
                case'key':if(value==0||value==1)  {
                    responseData.isOk=true;
                    changeKey(2,value,function(){
                    res.send(responseData);
                });}
                else {
                    responseData.isOk=false;
                    responseData.error="the value is incorrect，it should be '0'or'1'";
                    res.send(responseData);
                }
                break;
                default: 
                responseData.isOk=false;
                responseData.error="your key is not existent";
                res.send(responseData);
            }
            break;
            case '03':switch(key){
                case'speed':if(value>-1&&value<5&&source.air3.key==1)  {
                    responseData.isOk=true;
                    changeSpeed(3,value,function(){
                    res.send(responseData);
                });}
                else {
                    responseData.isOk=false;
                    responseData.error="the value is incorrect，it should be 0-4";
                    res.send(responseData);
                }
                break;
                case'temperature':
                if(value>19&&value<31&&source.air3.key==1){
                        responseData.isOk=true;
                        getAllState(function(){ 
                    changeValue(3,value,function(){
                    res.send(responseData);
                    });});}
                else {
                        responseData.isOk=false;
                        responseData.error="the value is incorrect，it should be 20-30";
                        res.send(responseData);
                    }
                break;
                case'mode':if(value>-1&&value<5&&source.air3.key==1)  {
                    responseData.isOk=true;
                    changeModel(3,value,function(){
                    res.send(responseData);
                });}
                else {
                    responseData.isOk=false;
                    responseData.error="the value is incorrect，it should be 0-4";
                    res.send(responseData);
                }
                break;
                case'key':if(value==0||value==1)  {
                    responseData.isOk=true;
                    changeKey(3,value,function(){
                    res.send(responseData);
                });}
                else {
                    responseData.isOk=false;
                    responseData.error="the value is incorrect，it should be '0'or'1'";
                    res.send(responseData);
                }
                break;
                default: 
                responseData.isOk=false;
                responseData.error="your key is not existent";
                res.send(responseData);
            }
            break;
            case '04':switch(key){
                case'speed':if(value>-1&&value<5&&source.air4.key==1)  {
                    responseData.isOk=true;
                    changeSpeed(4,value,function(){
                    res.send(responseData);
                });}
                else {
                    responseData.isOk=false;
                    responseData.error="the value is incorrect，it should be 0-4";
                    res.send(responseData);
                }
                break;
                case'temperature':
                if(value>19&&value<31&&source.air4.key==1){
                        responseData.isOk=true;
                        getAllState(function(){ 
                    changeValue(4,value,function(){
                    res.send(responseData);
                    });});}
                else {
                        responseData.isOk=false;
                        responseData.error="the value is incorrect，it should be 20-30";
                        res.send(responseData);
                    }
                break;
                case'mode':if(value>-1&&value<5&&source.air4.key==1)  {
                    responseData.isOk=true;
                    changeModel(4,value,function(){
                    res.send(responseData);
                });}
                else {
                    responseData.isOk=false;
                    responseData.error="the value is incorrect，it should be 0-4";
                    res.send(responseData);
                }
                break;
                case'key':if(value==0||value==1)  {
                    responseData.isOk=true;
                    changeKey(4,value,function(){
                    res.send(responseData);
                });}
                else {
                    responseData.isOk=false;
                    responseData.error="the value is incorrect，it should be '0'or'1'";
                    res.send(responseData);
                }
                break;
                default: 
                responseData.isOk=false;
                responseData.error="your key is not existent";
                res.send(responseData);
            }
            break;
            default: 
            responseData.isOk=false;
            responseData.error="your ID is not existent";
            res.send(responseData);
            }
});

app.listen(port,hostName,function(){
   console.log(`服务器运行在http://${hostName}:${port}`);
});