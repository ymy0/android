var request=require('request');
var data=require('./IntelligentRecommendation');
var requestData1,requestData2,requestData3,requestData4;
var recommand=function(num,callback){
if(num==1){
    requestData1={
        "request": {
            "device": { 
                "f0a825b7-c7be":{
                    "501-001": { 
                        "value_type": "int",
                        "value": "1" 
                    }}
            }
        },
        "meta":{                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
            "agent": "browser", 
            "type": "/device/car", 
            "requestAt": "", 
            "timeOut": 4000
        }
    };
    
    requestData2={
        "request": {
            "device": { 
                "f0a825b7-c7be":{
                    "502-001": { 
                        "value_type": "int",
                        "value": ""+data.powerSave.model+"" 
                    }
                }
            }
        },
        "meta": {                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
            "agent": "browser", 
            "type": "/device/car", 
            "requestAt": "", 
            "timeOut": 4000
        }
    };
    requestData3={
        "request": {
            "device": { 
                "f0a825b7-c7be":{
                    "502-002": { 
                        "value_type": "int",
                        "value": ""+data.powerSave.speed+"" 
                    }
                }
            }
        },
        "meta": {                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
            "agent": "browser", 
            "type": "/device/car", 
            "requestAt": "", 
            "timeOut": 4000
        }
    };
    requestData4={
        "request": {
            "device": { 
                "f0a825b7-c7be":{
                    "502-003": { 
                        "value_type": "double",
                        "value": ""+data.powerSave.value+"" 
                    }
                }
            }
        },
        "meta": {                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
            "agent": "browser", 
            "type": "/device/car", 
            "requestAt": "", 
            "timeOut": 4000
        }
    };

    request({
        url: "http://120.76.226.75:9527/simuac/v1/device/rtw",
        method: "POST",
        json: true,
        headers: {
            "content-type": "application/json",
        },
        body: requestData1
    }, function() {});
    request({
        url: "http://120.76.226.75:9527/simuac/v1/device/rtw",
        method: "POST",
        json: true,
        headers: {
            "content-type": "application/json",
        },
        body: requestData2
    }, function() {});
    request({
        url: "http://120.76.226.75:9527/simuac/v1/device/rtw",
        method: "POST",
        json: true,
        headers: {
            "content-type": "application/json",
        },
        body: requestData3
    }, function() {});
    request({
        url: "http://120.76.226.75:9527/simuac/v1/device/rtw",
        method: "POST",
        json: true,
        headers: {
            "content-type": "application/json",
        },
        body: requestData4
    }, function() {});
}
if(num==2){
    requestData1={
        "request": {
            "device": { 
                "c13efd70-f5ab":{
                    "501-001": { 
                        "value_type": "int",
                        "value": "1" 
                    }}
            }
        },
        "meta":{                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
            "agent": "browser", 
            "type": "/device/car", 
            "requestAt": "", 
            "timeOut": 4000
        }
};
    requestData2={
    "request": {
        "device": { 
            "c13efd70-f5ab":{
                "502-001": { 
                    "value_type": "int",
                    "value": ""+data.powerSave.model+"" 
                }
            }
        }
    },
    "meta": {                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
        "agent": "browser", 
        "type": "/device/car", 
        "requestAt": "", 
        "timeOut": 4000
    }
};
    requestData3={
    "request": {
        "device": { 
            "c13efd70-f5ab":{
                "502-002": { 
                    "value_type": "int",
                    "value": ""+data.powerSave.speed+"" 
                }
            }
        }
    },
    "meta": {                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
        "agent": "browser", 
        "type": "/device/car", 
        "requestAt": "", 
        "timeOut": 4000
    }
};
    requestData4={
    "request": {
        "device": { 
            "c13efd70-f5ab":{
                "502-003": { 
                    "value_type": "int",
                    "value": ""+data.powerSave.value+"" 
                }
            }
        }
    },
    "meta": {                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
        "agent": "browser", 
        "type": "/device/car", 
        "requestAt": "", 
        "timeOut": 4000
    }
};
    request({
    url: "http://120.76.226.75:9527/simuac/v1/device/rtw",
    method: "POST",
    json: true,
    headers: {
        "content-type": "application/json",
    },
    body: requestData1
    }, function() {});
    request({
    url: "http://120.76.226.75:9527/simuac/v1/device/rtw",
    method: "POST",
    json: true,
    headers: {
        "content-type": "application/json",
    },
    body: requestData2
    }, function() {});
    request({
    url: "http://120.76.226.75:9527/simuac/v1/device/rtw",
    method: "POST",
    json: true,
    headers: {
        "content-type": "application/json",
    },
    body: requestData3
    }, function() {});
    request({
    url: "http://120.76.226.75:9527/simuac/v1/device/rtw",
    method: "POST",
    json: true,
    headers: {
        "content-type": "application/json",
    },
    body: requestData4
    }, function() {});
}
if(num==3){
    requestData1={
        "request": {
            "device": { 
                "577b9999-39b1":{
                    "501-001": { 
                        "value_type": "int",
                        "value": "1" 
                    }}
            }
        },
        "meta": {                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
            "agent": "browser", 
            "type": "/device/car", 
            "requestAt": "", 
            "timeOut": 4000
        }
};
    requestData2={
    "request": {
        "device": { 
            "577b9999-39b1":{
                "502-001": { 
                    "value_type": "int",
                    "value": ""+data.powerSave.model+"" 
                }
            }
        }
    },
    "meta":{                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
        "agent": "browser", 
        "type": "/device/car", 
        "requestAt": "", 
        "timeOut": 4000
    }
};
    requestData3={
    "request": {
        "device": { 
            "577b9999-39b1":{
                "502-002": { 
                    "value_type": "int",
                    "value": ""+data.powerSave.speed+"" 
                }
            }
        }
    },
    "meta": {                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
        "agent": "browser", 
        "type": "/device/car", 
        "requestAt": "", 
        "timeOut": 4000
    }
};
    requestData4={
    "request": {
        "device": { 
            "577b9999-39b1":{
                "502-003": { 
                    "value_type": "double",
                    "value": ""+data.powerSave.value+"" 
                }
            }
        }
    },
    "meta": {                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
        "agent": "browser", 
        "type": "/device/car", 
        "requestAt": "", 
        "timeOut": 4000
    }
};
request({
    url: "http://120.76.226.75:9527/simuac/v1/device/rtw",
    method: "POST",
    json: true,
    headers: {
        "content-type": "application/json",
    },
    body: requestData1
}, function() {});
request({
    url: "http://120.76.226.75:9527/simuac/v1/device/rtw",
    method: "POST",
    json: true,
    headers: {
        "content-type": "application/json",
    },
    body: requestData2
}, function() {});
request({
    url: "http://120.76.226.75:9527/simuac/v1/device/rtw",
    method: "POST",
    json: true,
    headers: {
        "content-type": "application/json",
    },
    body: requestData3
}, function() {});
request({
    url: "http://120.76.226.75:9527/simuac/v1/device/rtw",
    method: "POST",
    json: true,
    headers: {
        "content-type": "application/json",
    },
    body: requestData4
}, function() {});
}
if(num==4){
    requestData1={
        "request": {
            "device": { 
                "f276ae0c-e603":{
                    "501-001": { 
                        "value_type": "int",
                        "value": "1" 
                    }}
            }
        },
        "meta": {                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
            "agent": "browser", 
            "type": "/device/car", 
            "requestAt": "", 
            "timeOut": 4000
        }
};
    requestData2={
    "request": {
        "device": { 
            "f276ae0c-e603":{
                "502-001": { 
                    "value_type": "int",
                    "value": ""+data.powerSave.model+"" 
                }
            }
        }
    },
    "meta":{                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
        "agent": "browser", 
        "type": "/device/car", 
        "requestAt": "", 
        "timeOut": 4000
    }
};
    requestData3={
    "request": {
        "device": { 
            "f276ae0c-e603":{
                "502-002": { 
                    "value_type": "int",
                    "value": ""+data.powerSave.speed+"" 
                }
            }
        }
    },
    "meta":{                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
        "agent": "browser", 
        "type": "/device/car", 
        "requestAt": "", 
        "timeOut": 4000
    }
};
    requestData4={
    "request": {
        "device": { 
            "f276ae0c-e603":{
                "502-003": { 
                    "value_type": "double",
                    "value": ""+data.powerSave.value+"" 
                }
            }
        }
    },
    "meta": {                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
        "agent": "browser", 
        "type": "/device/car", 
        "requestAt": "", 
        "timeOut": 4000
    }
};
request({
    url: "http://120.76.226.75:9527/simuac/v1/device/rtw",
    method: "POST",
    json: true,
    headers: {
        "content-type": "application/json",
    },
    body: requestData1
}, function() {});
request({
    url: "http://120.76.226.75:9527/simuac/v1/device/rtw",
    method: "POST",
    json: true,
    headers: {
        "content-type": "application/json",
    },
    body: requestData2
}, function() {});
request({
    url: "http://120.76.226.75:9527/simuac/v1/device/rtw",
    method: "POST",
    json: true,
    headers: {
        "content-type": "application/json",
    },
    body: requestData3
}, function() {});
request({
    url: "http://120.76.226.75:9527/simuac/v1/device/rtw",
    method: "POST",
    json: true,
    headers: {
        "content-type": "application/json",
    },
    body: requestData4
}, function() {});
}
    callback();
}
module.exports=recommand;
